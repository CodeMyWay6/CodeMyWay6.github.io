
var lineChart = document.getElementById("lineChart");
var lineChartCtx = lineChart.getContext("2d");

lineChart = new Chart(lineChartCtx, {
    type: 'line',
    data: '',
    options: {
        maintainAspectRatio: false,
        legend: {
            position: 'bottom',
            align: 'start',
            labels: {
                boxWidth: 2,
                fontColor: '#888888'
            }
        },
        scales: {
            xAxes: [{
                type: 'time',
                distribution: 'linear',
                ticks: {
                    source: 'auto',
                    fontColor: '#888888'
                },
                time: {
                        unit: 'month',
                        displayFormats: {
                            month: 'MMM YYYY'
                        }
                }
            }],
            yAxes: [{
                ticks: {
                    fontColor: '#888888'
                }
            }]
        },
        animation: {
            duration: 0
        },
        hover: {
            animationDuration: 0,
            mode: 'dataset'
        },
        responsiveAnimationDuration: 0,
    }
});

var pieChart = document.getElementById("pieChart");
var pieChartCtx = pieChart.getContext("2d");

pieChart = new Chart(pieChartCtx, {
    type: 'doughnut',
    data: '',
    options: {
        maintainAspectRatio: false,
        legend: {
            display: false
        },
        cutoutPercentage: 30,
        animation: {
            duration: 0
        },
        hover: {
            animationDuration: 0
        },
        responsiveAnimationDuration: 0,
    }
});

var weekDayChart = document.getElementById("weekDayChart");
var weekDayChartCtx = weekDayChart.getContext("2d");

weekDayChart = new Chart(weekDayChartCtx, {
    type: 'bar',
    data: '',
    options: {
        maintainAspectRatio: false,
        legend: {
            display: false
        },
        scales: {
            xAxes: [{
                ticks: {
                    source: 'auto',
                    fontColor: '#888888'
                }
            }],
            yAxes: [{
                ticks: {
                    fontColor: '#888888',
                    beginAtZero: true
                }
            }]
        },
        animation: {
            duration: 0
        },
        hover: {
            animationDuration: 0
        },
        responsiveAnimationDuration: 0,
    }
});

var dayHourChart = document.getElementById("dayHourChart");
var dayHourChartCtx = dayHourChart.getContext("2d");

dayHourChart = new Chart(dayHourChartCtx, {
    type: 'bar',
    data: '',
    options: {
        maintainAspectRatio: false,
        legend: {
            display: false
        },
        scales: {
            xAxes: [{
                ticks: {
                    fontColor: '#888888'
                }
            }],
            yAxes: [{
                ticks: {
                    fontColor: '#888888',
                    beginAtZero: true
                }
            }]
        },
        animation: {
            duration: 0
        },
        hover: {
            animationDuration: 0
        },
        responsiveAnimationDuration: 0,
    }
});

function updateLineChart(lineChartData) {
    lineChart.data.datasets = lineChartData;
    lineChart.update();
}

function updatePieChart(pieChartData) {
    pieChart.data = pieChartData;
    pieChart.update()
}

function updateWeekDayChart(weekDayChartData) {
    weekDayChart.data = weekDayChartData;
    weekDayChart.update()
}

function updateDayHourChart(dayHourChartData) {
    dayHourChart.data = dayHourChartData;
    dayHourChart.update()
}

function updateTable(users) {
    var tbody = document.getElementById("tableBody");
    tbody.innerHTML = '';
    for (let user of users) {
        let row = createRow(user);
        tbody.appendChild(row);
    }
}

function createRow(user) {
    var row = document.createElement("tr");

    var td1 = createTd(user.name);
    var td2 = createTd(user.count);
    td2.setAttribute("class", "text-right");
    
    row.appendChild(td1);
    row.appendChild(td2);

    return row;
}

function createTd(text) {
    var td = document.createElement("td");
    var text = document.createTextNode(text);
    td.appendChild(text);
    return td;
}
