#!/bin/sh

#  gpg.sh
#  Fork
#
#  Created by Danil on 19/10/2017.
#  Copyright © 2017 Danil. All rights reserved.

if test -f "/opt/homebrew/bin/gpg"; then
    /opt/homebrew/bin/gpg --batch --no-tty "$@"
elif test -f "/opt/local/bin/gpg"; then
    /opt/local/bin/gpg --batch --no-tty "$@"
else
    /usr/local/bin/gpg --batch --no-tty "$@"
fi
